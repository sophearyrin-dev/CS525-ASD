package counter;

public interface Observer {
	public void update(int countervalue);
}
